package jmt.bank.shared;

import jmt.bank.beans.Account;
import jmt.bank.beans.BankCard;
import jmt.bank.beans.Client;

public class BankService implements Authentication, Transaction {
	private static BankService singleton;

	private BankService () {
		Account.createAccounts();
	}
	
	public static BankService getInstance() {
		if(singleton == null) singleton = new BankService();
		return singleton;
	}
	
	@Override
	public String transfer(String debitAccountId, String creditAccountId,
			float amount) throws TransactionException {
		
		Account debitAccount = Account.getAccount(debitAccountId);
		Account creditAccount = Account.getAccount(creditAccountId);
		
		if (debitAccount == null) {
			// Not a valid debit account
			throw new TransactionException("Debit account (" + debitAccountId + ") does not exist.");
		}
		
		// Amount to high
		if (amount > debitAccount.getBalance()) {
			throw new TransactionException("Amount exceeds current balance.");
		} else if (creditAccount == null) {
			// Not a valid target account
			throw new TransactionException("Target account (" + creditAccountId + ") does not exist.");
		} else {
			// Transfer the amount to the creditAccount
			debitAccount.setBalance(debitAccount.getBalance() - amount);
			creditAccount.setBalance(creditAccount.getBalance() + amount);
		}
		
		return "Successfully transferred &euro; " + amount + " to " + creditAccountId;
	}

	@Override
	public String deposit(String creditAccountId, float amount) throws TransactionException {
		Account acc = Account.getAccount(creditAccountId);
		if (acc == null) throw new TransactionException("Credit account (" + creditAccountId + ") does not exist");
		acc.setBalance(acc.getBalance() + amount);
		return "Deposited &euro; " + amount + " to your account!";
	}
	
	@Override
	public String withdraw(String debitAccountId, float amount)
			throws TransactionException {
		Account acc = Account.getAccount(debitAccountId);
		if (acc == null) {
			throw new TransactionException("Debit account (" + debitAccountId + ") does not exist");
		} else if(acc.getBalance() > amount) {
			acc.setBalance(acc.getBalance() - amount);
		} else {
			throw new TransactionException("The amount is bigger than your current balance");
		}
		return "Withdrawn &euro; " + amount + " from your account!";
	}

	@Override
	public float getBalance(String accountId) throws TransactionException {
		Account account = Account.getAccount(accountId);
		
		if (account == null) throw new TransactionException();
		return account.getBalance();
	}

	@Override
	public void authenticateClient(String username, String password)
			throws AuthenticationException {
		Client client = Client.getClient(username);
		if (client == null) {
			throw new AuthenticationException("Invalid username");
		} else {
			if (!client.getPassword().equals(password)) {
				throw new AuthenticationException("Invalid password");
			}
		}

	}

	@Override
	public void authenticateCard(String cardId, String PIN)
			throws AuthenticationException {
		BankCard card = BankCard.getBankCard(cardId);
		if(card == null) {
			throw new AuthenticationException("Invalid BankCard ID");
		} else {
			if(!card.getPinCode().equals(PIN)) {
				throw new AuthenticationException("Invalid PIN code");
			}
		}
	}

}
