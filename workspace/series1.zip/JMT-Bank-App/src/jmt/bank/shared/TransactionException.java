package jmt.bank.shared;


@SuppressWarnings("serial")
public class TransactionException extends Exception {
	public TransactionException() {
		super();
	}
	
	public TransactionException(String s) {
		super(s);
	}

}
