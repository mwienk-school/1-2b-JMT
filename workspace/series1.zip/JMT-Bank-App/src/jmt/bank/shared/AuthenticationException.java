package jmt.bank.shared;


@SuppressWarnings("serial")
public class AuthenticationException extends Exception {
	
	public AuthenticationException() {}

	public AuthenticationException(String string) {
		super(string);
	}
}
